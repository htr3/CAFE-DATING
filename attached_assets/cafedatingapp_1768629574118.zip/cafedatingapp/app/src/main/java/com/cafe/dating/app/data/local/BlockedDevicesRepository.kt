package com.cafe.dating.app.data.local

import android.content.Context
import android.content.SharedPreferences

/**
 * Repository for managing blocked devices
 */
class BlockedDevicesRepository(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(
        "blocked_devices",
        Context.MODE_PRIVATE
    )

    /**
     * Block a device by UUID
     */
    fun blockDevice(deviceUUID: String) {
        prefs.edit().putBoolean(deviceUUID, true).apply()
    }

    /**
     * Check if device is blocked
     */
    fun isBlocked(deviceUUID: String): Boolean {
        return prefs.getBoolean(deviceUUID, false)
    }

    /**
     * Unblock a device
     */
    fun unblockDevice(deviceUUID: String) {
        prefs.edit().remove(deviceUUID).apply()
    }

    /**
     * Get all blocked device UUIDs
     */
    fun getAllBlockedDevices(): Set<String> {
        return prefs.all.keys
    }
}