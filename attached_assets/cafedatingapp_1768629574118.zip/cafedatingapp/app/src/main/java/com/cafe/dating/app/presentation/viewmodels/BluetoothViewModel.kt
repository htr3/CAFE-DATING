package com.cafe.dating.app.presentation.viewmodels


import android.app.Application
import android.bluetooth.BluetoothAdapter
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cafe.dating.app.data.local.BlockedDevicesRepository
import com.cafe.dating.app.data.local.SecurePreferences
import com.cafe.dating.app.data.model.BluetoothDeviceModel
import com.cafe.dating.app.domain.bluetooth.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class BluetoothViewModel(application: Application) : AndroidViewModel(application) {

    private val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
    private val securePrefs = SecurePreferences(application)
    private val blockedDevices = BlockedDevicesRepository(application)

    private val discoveryManager = DiscoveryManager(
        application,
        bluetoothAdapter,
        blockedDevices
    )

    private lateinit var bluetoothServer: BluetoothServer
    private val bluetoothClient = BluetoothClient(bluetoothAdapter, securePrefs)

    val discoveredDevices = discoveryManager.discoveredDevices
    val isScanning = discoveryManager.isScanning

    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Idle)
    val connectionState: StateFlow<ConnectionState> = _connectionState

    private val _connectionRequest = MutableStateFlow<ConnectionRequest?>(null)
    val connectionRequest: StateFlow<ConnectionRequest?> = _connectionRequest

    private var currentSocket: SecureSocketManager? = null

    sealed class ConnectionState {
        object Idle : ConnectionState()
        object Connecting : ConnectionState()
        data class Connected(val deviceName: String) : ConnectionState()
        data class Error(val message: String) : ConnectionState()
    }

    data class ConnectionRequest(
        val deviceName: String,
        val deviceUUID: String
    )

    init {
        bluetoothServer = BluetoothServer(
            bluetoothAdapter,
            securePrefs,
            blockedDevices
        ) { uuid, name ->
            _connectionRequest.value = ConnectionRequest(name, uuid)
            waitForConnectionDecision()
        }

        viewModelScope.launch {
            bluetoothServer.connectionFlow.collect { event ->
                when (event) {
                    is BluetoothServer.ServerEvent.ConnectionEstablished -> {
                        handleConnection(event.socket, event.deviceUUID)
                    }
                    is BluetoothServer.ServerEvent.Error -> {
                        _connectionState.value = ConnectionState.Error(event.message)
                    }
                    else -> {}
                }
            }
        }

        viewModelScope.launch {
            bluetoothClient.connectionFlow.collect { event ->
                when (event) {
                    is BluetoothClient.ClientEvent.Connecting -> {
                        _connectionState.value = ConnectionState.Connecting
                    }
                    is BluetoothClient.ClientEvent.Connected -> {
                        handleConnection(event.socket, event.deviceUUID)
                    }
                    is BluetoothClient.ClientEvent.Failed -> {
                        _connectionState.value = ConnectionState.Error(event.reason)
                    }
                }
            }
        }
    }

    fun startAutoMode() {
        bluetoothServer.start(getApplication())
        discoveryManager.startDiscovery()
    }

    fun stopAll() {
        bluetoothServer.stop()
        discoveryManager.stopDiscovery()
        currentSocket?.close()
        currentSocket = null
    }

    fun connectToDevice(device: BluetoothDeviceModel) {
        viewModelScope.launch {
            bluetoothClient.connect(getApplication(), device.address)
        }
    }

    fun acceptConnection() {
        connectionDecision = true
        _connectionRequest.value = null
    }

    fun rejectConnection() {
        connectionDecision = false
        _connectionRequest.value = null
    }

    fun blockDevice(deviceUUID: String) {
        blockedDevices.blockDevice(deviceUUID)
        currentSocket?.close()
        _connectionState.value = ConnectionState.Idle
    }

    fun disconnect() {
        currentSocket?.close()
        currentSocket = null
        _connectionState.value = ConnectionState.Idle
        startAutoMode()
    }

    fun getCurrentSocket(): SecureSocketManager? = currentSocket

    private var connectionDecision: Boolean? = null

    private suspend fun waitForConnectionDecision(): Boolean {
        connectionDecision = null

        var waitTime = 0
        while (connectionDecision == null && waitTime < 30000) {
            kotlinx.coroutines.delay(100)
            waitTime += 100
        }

        return connectionDecision ?: false
    }

    private fun handleConnection(socket: SecureSocketManager, deviceUUID: String) {
        currentSocket = socket
        _connectionState.value = ConnectionState.Connected("User")
        discoveryManager.stopDiscovery()
        socket.startListening()
    }

    override fun onCleared() {
        super.onCleared()
        stopAll()
    }
}