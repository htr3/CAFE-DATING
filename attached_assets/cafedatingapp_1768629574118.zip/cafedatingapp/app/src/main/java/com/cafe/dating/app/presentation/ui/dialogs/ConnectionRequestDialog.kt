package com.cafe.dating.app.presentation.ui.dialogs


import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.text.font.FontWeight

@Composable
fun ConnectionRequestDialog(
    deviceName: String,
    onAccept: () -> Unit,
    onReject: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onReject,
        icon = {
            Text(text = "📱", style = MaterialTheme.typography.displaySmall)
        },
        title = {
            Text(
                text = "Connection Request",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Text(
                text = "$deviceName wants to connect and start a secure chat. Accept this connection?",
                style = MaterialTheme.typography.bodyLarge
            )
        },
        confirmButton = {
            Button(onClick = onAccept) {
                Text("✅ Accept")
            }
        },
        dismissButton = {
            TextButton(onClick = onReject) {
                Text("❌ Reject")
            }
        }
    )
}