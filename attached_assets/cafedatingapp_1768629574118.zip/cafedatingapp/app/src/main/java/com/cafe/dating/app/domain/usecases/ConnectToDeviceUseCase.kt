package com.cafe.dating.app.domain.usecases


import com.cafe.dating.app.data.model.BluetoothDeviceModel
import com.cafe.dating.app.domain.bluetooth.BluetoothClient
import com.cafe.dating.app.domain.bluetooth.SecureSocketManager

/**
 * Use case for connecting to a remote Bluetooth device
 * Handles client-side connection logic
 */
class ConnectToDeviceUseCase(
    private val bluetoothClient: BluetoothClient
) {

    sealed class Result {
        data class Success(val socket: SecureSocketManager) : Result()
        data class Failure(val error: String) : Result()
    }

    /**
     * Execute connection to device
     */
    suspend operator fun invoke(
        context: android.content.Context,
        device: BluetoothDeviceModel
    ): Result {
        return try {
            val socket = bluetoothClient.connect(context, device.address)

            if (socket != null) {
                Result.Success(socket)
            } else {
                Result.Failure("Connection failed")
            }
        } catch (e: Exception) {
            Result.Failure(e.message ?: "Unknown error")
        }
    }
}
