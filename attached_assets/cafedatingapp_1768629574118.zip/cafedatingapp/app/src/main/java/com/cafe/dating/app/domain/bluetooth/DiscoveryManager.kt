package com.cafe.dating.app.domain.bluetooth


import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresPermission
import androidx.core.app.ActivityCompat
import com.cafe.dating.app.data.local.BlockedDevicesRepository
import com.cafe.dating.app.data.model.BluetoothDeviceModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * FIXED: Discovery Manager with debug logging
 */
class DiscoveryManager(
    private val context: Context,
    private val bluetoothAdapter: BluetoothAdapter?,
    private val blockedDevices: BlockedDevicesRepository
) {

    companion object {
        private const val TAG = "DiscoveryManager"
    }

    private val _discoveredDevices = MutableStateFlow<List<BluetoothDeviceModel>>(emptyList())
    val discoveredDevices: StateFlow<List<BluetoothDeviceModel>> = _discoveredDevices

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning

    private val discoveryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            Log.d(TAG, "Broadcast received: ${intent?.action}")

            when (intent?.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    handleDeviceFound(intent)
                }
                BluetoothAdapter.ACTION_DISCOVERY_STARTED -> {
                    Log.d(TAG, "Discovery STARTED")
                    _isScanning.value = true
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                    Log.d(TAG, "Discovery FINISHED")
                    handleDiscoveryFinished()
                }
            }
        }
    }

    private var isReceiverRegistered = false
    private var rescanThread: Thread? = null

    /**
     * Start continuous discovery
     */
    fun startDiscovery() {
        Log.d(TAG, "startDiscovery() called")

        if (!checkPermissions()) {
            Log.e(TAG, "Permissions not granted!")
            return
        }

        if (bluetoothAdapter == null) {
            Log.e(TAG, "BluetoothAdapter is null!")
            return
        }

        if (!bluetoothAdapter.isEnabled) {
            Log.e(TAG, "Bluetooth is not enabled!")
            return
        }

        // Register receiver
        if (!isReceiverRegistered) {
            val filter = IntentFilter().apply {
                addAction(BluetoothDevice.ACTION_FOUND)
                addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED)
                addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            }

            try {
                context.registerReceiver(discoveryReceiver, filter)
                isReceiverRegistered = true
                Log.d(TAG, "Receiver registered successfully")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to register receiver: ${e.message}")
                return
            }
        }

        // Start scanning
        performDiscovery()
    }

    /**
     * Stop discovery
     */
    @RequiresPermission(Manifest.permission.BLUETOOTH_SCAN)
    fun stopDiscovery() {
        Log.d(TAG, "stopDiscovery() called")

        try {
            bluetoothAdapter?.cancelDiscovery()
            rescanThread?.interrupt()
            rescanThread = null

            if (isReceiverRegistered) {
                context.unregisterReceiver(discoveryReceiver)
                isReceiverRegistered = false
                Log.d(TAG, "Receiver unregistered")
            }

            _isScanning.value = false
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping discovery: ${e.message}")
        }
    }

    /**
     * Clear discovered devices
     */
    fun clearDevices() {
        _discoveredDevices.value = emptyList()
        Log.d(TAG, "Devices cleared")
    }

    private fun performDiscovery() {
        if (!checkPermissions()) {
            Log.e(TAG, "Cannot perform discovery - no permissions")
            return
        }

        try {
            // Cancel any ongoing discovery
            if (bluetoothAdapter?.isDiscovering == true) {
                Log.d(TAG, "Canceling ongoing discovery")
                bluetoothAdapter.cancelDiscovery()
                Thread.sleep(500) // Wait a bit before starting new discovery
            }

            // Start new discovery
            Log.d(TAG, "Starting discovery...")
            val started = bluetoothAdapter?.startDiscovery()

            if (started == true) {
                Log.d(TAG, "✅ Discovery started successfully")
                _isScanning.value = true
            } else {
                Log.e(TAG, "❌ Failed to start discovery (returned false)")
                _isScanning.value = false
            }
        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException: ${e.message}")
            _isScanning.value = false
        } catch (e: Exception) {
            Log.e(TAG, "Exception during discovery: ${e.message}")
            _isScanning.value = false
        }
    }

    private fun handleDeviceFound(intent: Intent) {
        if (!checkPermissions()) return

        try {
            val device: BluetoothDevice? =
                intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)

            if (device == null) {
                Log.w(TAG, "Device is null in ACTION_FOUND")
                return
            }

            Log.d(TAG, "Device found - Name: ${device.name}, Address: ${device.address}")

            // Check if device has a name
            if (device.name.isNullOrBlank()) {
                Log.d(TAG, "Skipping device with no name: ${device.address}")
                return
            }

            val deviceModel = BluetoothDeviceModel(
                name = device.name,
                address = device.address
            )

            // Check if already in list
            val currentDevices = _discoveredDevices.value.toMutableList()
            if (currentDevices.any { it.address == deviceModel.address }) {
                Log.d(TAG, "Device already in list: ${device.name}")
                return
            }

            // Add to list
            currentDevices.add(deviceModel)
            _discoveredDevices.value = currentDevices

            Log.d(TAG, "✅ Device added! Total devices: ${currentDevices.size}")

        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException reading device: ${e.message}")
        } catch (e: Exception) {
            Log.e(TAG, "Exception handling device: ${e.message}")
        }
    }

    private fun handleDiscoveryFinished() {
        _isScanning.value = false

        val deviceCount = _discoveredDevices.value.size
        Log.d(TAG, "Discovery finished. Found $deviceCount devices")

        // Auto-rescan after 3 seconds
        rescanThread?.interrupt()
        rescanThread = Thread {
            try {
                Log.d(TAG, "Waiting 3 seconds before rescanning...")
                Thread.sleep(3000)
                Log.d(TAG, "Starting rescan...")
                performDiscovery()
            } catch (e: InterruptedException) {
                Log.d(TAG, "Rescan interrupted")
            }
        }.apply { start() }
    }

    private fun checkPermissions(): Boolean {
        // Check Bluetooth SCAN permission (Android 12+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val hasScan = ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.BLUETOOTH_SCAN
            ) == PackageManager.PERMISSION_GRANTED

            if (!hasScan) {
                Log.e(TAG, "BLUETOOTH_SCAN permission not granted")
                return false
            }
        }

        // Check Location permission (required for discovery)
        val hasLocation = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        }

        if (!hasLocation) {
            Log.e(TAG, "Location permission not granted")
            return false
        }

        Log.d(TAG, "✅ All permissions granted")
        return true
    }
}