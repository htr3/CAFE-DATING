package com.cafe.dating.app.data.model

data class BluetoothDeviceModel(
    val name: String,
    val address: String,
    val deviceUUID: String? = null,
    val isBlocked: Boolean = false
)