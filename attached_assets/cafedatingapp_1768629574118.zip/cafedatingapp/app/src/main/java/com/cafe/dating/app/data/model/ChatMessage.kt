package com.cafe.dating.app.data.model

data class ChatMessage(
    val id: String,
    val content: String,
    val timestamp: Long,
    val isSent: Boolean,
    val isEncrypted: Boolean = true
)