package com.cafe.dating.app.domain.bluetooth


import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import com.cafe.dating.app.data.local.BlockedDevicesRepository
import com.cafe.dating.app.data.local.SecurePreferences
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.runBlocking
import java.util.UUID

class BluetoothServer(
    private val bluetoothAdapter: BluetoothAdapter?,
    private val securePrefs: SecurePreferences,
    private val blockedDevices: BlockedDevicesRepository,
    private val onConnectionRequest: suspend (String, String) -> Boolean
) {

    companion object {
        private val APP_UUID = UUID.fromString("8ce255c0-200a-11e0-ac64-0800200c9a66")
        private const val SERVER_NAME = "CafeDatingServer"
    }

    private var serverSocket: BluetoothServerSocket? = null
    private var isRunning = false
    private var serverThread: Thread? = null

    private val _connectionFlow = MutableSharedFlow<ServerEvent>()
    val connectionFlow: SharedFlow<ServerEvent> = _connectionFlow

    sealed class ServerEvent {
        object Started : ServerEvent()
        object Stopped : ServerEvent()
        data class ConnectionRequested(val deviceName: String, val deviceUUID: String) : ServerEvent()
        data class ConnectionEstablished(val socket: SecureSocketManager, val deviceUUID: String) : ServerEvent()
        data class Error(val message: String) : ServerEvent()
    }

    fun start(context: Context): Boolean {
        if (isRunning) return true
        if (bluetoothAdapter == null) return false

        if (ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.BLUETOOTH_CONNECT
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return false
        }

        return try {
            serverSocket = bluetoothAdapter.listenUsingRfcommWithServiceRecord(
                SERVER_NAME,
                APP_UUID
            )

            isRunning = true
            serverThread = Thread {
                runServerLoop()
            }.apply { start() }

            _connectionFlow.tryEmit(ServerEvent.Started)
            true
        } catch (e: Exception) {
            _connectionFlow.tryEmit(ServerEvent.Error(e.message ?: "Failed to start server"))
            false
        }
    }

    fun stop() {
        isRunning = false
        try {
            serverSocket?.close()
            serverThread?.interrupt()
        } catch (e: Exception) {
            // Ignore
        }
        _connectionFlow.tryEmit(ServerEvent.Stopped)
    }

    private fun runServerLoop() {
        val handshakeManager = HandshakeManager()
        val myUUID = securePrefs.getDeviceUUID()

        while (isRunning) {
            try {
                val socket: BluetoothSocket = serverSocket?.accept() ?: break

                Thread {
                    handleIncomingConnection(socket, handshakeManager, myUUID)
                }.start()

            } catch (e: Exception) {
                if (isRunning) {
                    _connectionFlow.tryEmit(ServerEvent.Error("Accept failed: ${e.message}"))
                }
                break
            }
        }
    }

    private fun handleIncomingConnection(
        socket: BluetoothSocket,
        handshakeManager: HandshakeManager,
        myUUID: String
    ) {
        try {
            val result = handshakeManager.performServerHandshake(
                socket.inputStream,
                socket.outputStream
            ) { clientUUID, clientName ->
                if (blockedDevices.isBlocked(clientUUID)) {
                    return@performServerHandshake false
                }

                _connectionFlow.tryEmit(
                    ServerEvent.ConnectionRequested(clientName, clientUUID)
                )

                runBlocking {
                    onConnectionRequest(clientUUID, clientName)
                }
            }

            if (result != null) {
                val (clientUUID, sessionKey) = result
                val secureSocket = SecureSocketManager(socket, sessionKey, clientUUID)

                _connectionFlow.tryEmit(
                    ServerEvent.ConnectionEstablished(secureSocket, clientUUID)
                )
            } else {
                socket.close()
            }
        } catch (e: Exception) {
            try {
                socket.close()
            } catch (e: Exception) {
                // Ignore
            }
        }
    }
}