package com.cafe.dating.app.data.encryption


import android.util.Base64
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * AES-256 Encryption for secure message transmission
 * Thread-safe encryption/decryption utilities
 */
object EncryptionUtils {

    private const val ALGORITHM = "AES"
    private const val TRANSFORMATION = "AES/CBC/PKCS5Padding"
    private const val KEY_SIZE = 256
    private const val IV_SIZE = 16

    /**
     * Generate a new AES session key
     */
    fun generateSessionKey(): SecretKey {
        val keyGen = KeyGenerator.getInstance(ALGORITHM)
        keyGen.init(KEY_SIZE, SecureRandom())
        return keyGen.generateKey()
    }

    /**
     * Convert SecretKey to Base64 string for transmission
     */
    fun keyToString(key: SecretKey): String {
        return Base64.encodeToString(key.encoded, Base64.NO_WRAP)
    }

    /**
     * Convert Base64 string back to SecretKey
     */
    fun stringToKey(keyString: String): SecretKey {
        val keyBytes = Base64.decode(keyString, Base64.NO_WRAP)
        return SecretKeySpec(keyBytes, ALGORITHM)
    }

    /**
     * Encrypt a message with AES-256
     * Returns: IV + encrypted message (Base64 encoded)
     */
    fun encrypt(message: String, key: SecretKey): String {
        val cipher = Cipher.getInstance(TRANSFORMATION)

        // Generate random IV for each message
        val iv = ByteArray(IV_SIZE)
        SecureRandom().nextBytes(iv)
        val ivSpec = IvParameterSpec(iv)

        cipher.init(Cipher.ENCRYPT_MODE, key, ivSpec)
        val encrypted = cipher.doFinal(message.toByteArray(Charsets.UTF_8))

        // Combine IV + encrypted data
        val combined = iv + encrypted
        return Base64.encodeToString(combined, Base64.NO_WRAP)
    }

    /**
     * Decrypt a message with AES-256
     * Input: IV + encrypted message (Base64 encoded)
     */
    fun decrypt(encryptedMessage: String, key: SecretKey): String {
        val combined = Base64.decode(encryptedMessage, Base64.NO_WRAP)

        // Extract IV and encrypted data
        val iv = combined.copyOfRange(0, IV_SIZE)
        val encrypted = combined.copyOfRange(IV_SIZE, combined.size)

        val cipher = Cipher.getInstance(TRANSFORMATION)
        val ivSpec = IvParameterSpec(iv)

        cipher.init(Cipher.DECRYPT_MODE, key, ivSpec)
        val decrypted = cipher.doFinal(encrypted)

        return String(decrypted, Charsets.UTF_8)
    }
}