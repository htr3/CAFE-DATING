// ============================================================================
// FINAL COMPLETE MAINACTIVITY
// This includes everything needed for production
// ============================================================================

package com.cafe.dating.app

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.cafe.dating.app.presentation.ui.dialogs.ConnectionRequestDialog
import com.cafe.dating.app.presentation.ui.screens.ChatScreen
import com.cafe.dating.app.presentation.ui.screens.NearbyUsersScreen
import com.cafe.dating.app.presentation.viewmodels.BluetoothViewModel
import com.cafe.dating.app.presentation.viewmodels.ChatViewModel
import com.cafe.dating.app.ui.theme.CafeDatingAppTheme
import com.cafe.dating.app.utils.PermissionManager

class MainActivity : ComponentActivity() {

    private val bluetoothViewModel: BluetoothViewModel by viewModels()
    private val chatViewModel: ChatViewModel by viewModels()
    private val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()

    // ========================================================================
    // PERMISSION LAUNCHER
    // ========================================================================
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.values.all { it }

        if (allGranted) {
            Toast.makeText(
                this,
                "✅ Permissions granted! Starting.......",
                Toast.LENGTH_SHORT
            ).show()

            // Make device discoverable then start auto mode
            makeDeviceDiscoverable()
        } else {
            // Show which permissions were denied
            val denied = permissions.filter { !it.value }

            Toast.makeText(
                this,
                "❌ Some permissions were denied",
                Toast.LENGTH_LONG
            ).show()

            // Show detailed explanation
            denied.keys.forEach { permission ->
                val explanation = PermissionManager.getPermissionExplanation(permission)
                Toast.makeText(this, "⚠️ $explanation", Toast.LENGTH_LONG).show()
            }

            // Show settings button to grant manually
            showPermissionSettingsDialog()
        }
    }

    // ========================================================================
    // BLUETOOTH ENABLE LAUNCHER
    // ========================================================================
    private val bluetoothEnableLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (bluetoothAdapter?.isEnabled == true) {
            Toast.makeText(this, "✅ Bluetooth enabled", Toast.LENGTH_SHORT).show()
            requestPermissionsIfNeeded()
        } else {
            Toast.makeText(
                this,
                "❌ Bluetooth is required for this app",
                Toast.LENGTH_LONG
            ).show()
            finish()
        }
    }

    // ========================================================================
    // DISCOVERABLE MODE LAUNCHER
    // ========================================================================
    private val discoverableLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        // Regardless of result, start auto mode
        // User might have denied discoverable, but we can still scan
        bluetoothViewModel.startAutoMode()

        if (result.resultCode > 0) {
            Toast.makeText(
                this,
                "✅ You're visible to nearby users for ${result.resultCode} seconds",
                Toast.LENGTH_SHORT
            ).show()
        } else {
            Toast.makeText(
                this,
                "ℹ️ You can scan for others, but they can't see you",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    // ========================================================================
    // LIFECYCLE
    // ========================================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Check Bluetooth support
        if (bluetoothAdapter == null) {
            Toast.makeText(
                this,
                "❌ Bluetooth not supported on this device",
                Toast.LENGTH_LONG
            ).show()
            finish()
            return
        }

        setContent {
            CafeDatingAppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MainScreen(
                        bluetoothViewModel = bluetoothViewModel,
                        chatViewModel = chatViewModel,
                        onOpenSettings = { openAppSettings() }
                    )
                }
            }
        }

        // Start initialization
        checkBluetoothAndStart()
    }

    override fun onResume() {
        super.onResume()

        // Restart discovery if not connected and permissions granted
        val connectionState = bluetoothViewModel.connectionState.value

        if (connectionState is BluetoothViewModel.ConnectionState.Idle) {
            if (PermissionManager.hasAllPermissions(this) &&
                bluetoothAdapter?.isEnabled == true) {
                bluetoothViewModel.startAutoMode()
            }
        }
    }

    override fun onPause() {
        super.onPause()

        // Stop discovery when app goes to background (battery optimization)
        // But keep connection alive if chatting
        val connectionState = bluetoothViewModel.connectionState.value

        if (connectionState is BluetoothViewModel.ConnectionState.Idle ||
            connectionState is BluetoothViewModel.ConnectionState.Error) {
            bluetoothViewModel.stopAll()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        bluetoothViewModel.stopAll()
        chatViewModel.disconnect()
    }

    // ========================================================================
    // INITIALIZATION FLOW
    // ========================================================================

    private fun checkBluetoothAndStart() {
        when {
            // Check if Bluetooth is enabled
            bluetoothAdapter?.isEnabled == false -> {
                requestEnableBluetooth()
            }
            // Check permissions
            !PermissionManager.hasAllPermissions(this) -> {
                showPermissionRationaleDialog()
            }
            // Everything ready, start
            else -> {
                makeDeviceDiscoverable()
            }
        }
    }

    private fun requestEnableBluetooth() {
        val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
        bluetoothEnableLauncher.launch(enableBtIntent)
    }

    private fun showPermissionRationaleDialog() {
        // You can add a dialog here explaining why permissions are needed
        // For now, directly request
        requestPermissionsIfNeeded()
    }

    private fun requestPermissionsIfNeeded() {
        val missingPermissions = PermissionManager.getMissingPermissions(this)

        if (missingPermissions.isNotEmpty()) {
            Toast.makeText(
                this,
                "📱 Please grant all permissions to find nearby users",
                Toast.LENGTH_LONG
            ).show()

            permissionLauncher.launch(missingPermissions.toTypedArray())
        } else {
            makeDeviceDiscoverable()
        }
    }

    private fun makeDeviceDiscoverable() {
        try {
            val discoverableIntent = Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE).apply {
                putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300) // 5 minutes
            }
            discoverableLauncher.launch(discoverableIntent)
        } catch (e: Exception) {
            // If discoverable request fails, still start auto mode
            bluetoothViewModel.startAutoMode()
        }
    }

    private fun showPermissionSettingsDialog() {
        // Show dialog suggesting user to go to settings
        Toast.makeText(
            this,
            "⚙️ Please enable all permissions in Settings",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun openAppSettings() {
        val intent = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = android.net.Uri.fromParts("package", packageName, null)
        }
        startActivity(intent)
    }
}

// ============================================================================
// MAIN SCREEN COMPOSABLE
// ============================================================================

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun MainScreen(
    bluetoothViewModel: BluetoothViewModel,
    chatViewModel: ChatViewModel,
    onOpenSettings: () -> Unit
) {
    // Collect states
    val discoveredDevices by bluetoothViewModel.discoveredDevices.collectAsStateWithLifecycle()
    val isScanning by bluetoothViewModel.isScanning.collectAsStateWithLifecycle()
    val connectionRequest by bluetoothViewModel.connectionRequest.collectAsStateWithLifecycle()
    val connectionState by bluetoothViewModel.connectionState.collectAsStateWithLifecycle()

    // Current screen state
    var currentScreen by remember { mutableStateOf<AppScreen>(AppScreen.Discovery) }
    var connectedDeviceName by remember { mutableStateOf("") }

    // Handle connection state changes
    LaunchedEffect(connectionState) {
        when (val state = connectionState) {
            is BluetoothViewModel.ConnectionState.Connected -> {
                val socket = bluetoothViewModel.getCurrentSocket()
                if (socket != null) {
                    connectedDeviceName = state.deviceName
                    chatViewModel.initializeChat(socket, state.deviceName)
                    currentScreen = AppScreen.Chat
                }
            }
            is BluetoothViewModel.ConnectionState.Idle -> {
                if (currentScreen == AppScreen.Chat) {
                    currentScreen = AppScreen.Discovery
                }
            }
            is BluetoothViewModel.ConnectionState.Error -> {
                if (currentScreen == AppScreen.Chat) {
                    currentScreen = AppScreen.Discovery
                }
            }
            else -> {}
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize()
    ) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            // Animated screen transition
            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = {
                    fadeIn() + slideInHorizontally() with
                            fadeOut() + slideOutHorizontally()
                }
            ) { screen ->
                when (screen) {
                    AppScreen.Discovery -> {
                        NearbyUsersScreen(
                            devices = discoveredDevices,
                            isScanning = isScanning,
                            onDeviceClick = { device ->
                                bluetoothViewModel.connectToDevice(device)
                            },
                            onRefresh = {
                                bluetoothViewModel.startAutoMode()
                            }
                        )
                    }
                    AppScreen.Chat -> {
                        ChatScreen(
                            viewModel = chatViewModel,
                            deviceName = connectedDeviceName,
                            onDisconnect = {
                                chatViewModel.disconnect()
                                bluetoothViewModel.disconnect()
                                currentScreen = AppScreen.Discovery
                            },
                            onBlock = {
                                // Get device UUID and block
                                chatViewModel.disconnect()
                                bluetoothViewModel.disconnect()
                                currentScreen = AppScreen.Discovery
                            }
                        )
                    }
                }
            }

            // Connection Request Dialog (overlay)
            connectionRequest?.let { request ->
                ConnectionRequestDialog(
                    deviceName = request.deviceName,
                    onAccept = {
                        bluetoothViewModel.acceptConnection()
                    },
                    onReject = {
                        bluetoothViewModel.rejectConnection()
                    }
                )
            }

            // Connection Status Overlays
            when (connectionState) {
                is BluetoothViewModel.ConnectionState.Connecting -> {
                    ConnectingOverlay()
                }
                is BluetoothViewModel.ConnectionState.Error -> {
                    val error = (connectionState as BluetoothViewModel.ConnectionState.Error).message
                    ErrorOverlay(error)
                }
                else -> {}
            }
        }
    }
}

// ============================================================================
// SCREEN NAVIGATION
// ============================================================================

sealed class AppScreen {
    object Discovery : AppScreen()
    object Chat : AppScreen()
}

// ============================================================================
// OVERLAY COMPONENTS
// ============================================================================

@Composable
fun ConnectingOverlay() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Row(
                modifier = Modifier.padding(24.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                CircularProgressIndicator()
                Column {
                    Text(
                        text = "Connecting...",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = "🔒 Establishing secure connection",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun ErrorOverlay(errorMessage: String) {
    var showError by remember { mutableStateOf(true) }

    // Auto-dismiss after 4 seconds
    LaunchedEffect(errorMessage) {
        kotlinx.coroutines.delay(4000)
        showError = false
    }

    if (showError) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.TopCenter
        ) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "❌",
                        style = MaterialTheme.typography.headlineMedium
                    )
                    Column {
                        Text(
                            text = "Connection Failed",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                        Text(
                            text = errorMessage,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }
        }
    }
}

// ============================================================================
// ADDITIONAL: Permission Explanation Dialog (Optional)
// ============================================================================

@Composable
fun PermissionExplanationDialog(
    onDismiss: () -> Unit,
    onGrantPermissions: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Text(text = "📱", style = MaterialTheme.typography.displaySmall)
        },
        title = {
            Text("Permissions Required")
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "This app needs the following permissions:",
                    style = MaterialTheme.typography.bodyMedium
                )

                Text(
                    text = "🔵 Bluetooth",
                    style = MaterialTheme.typography.titleSmall
                )
                Text(
                    text = "To discover and connect with nearby users",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "📍 Location",
                    style = MaterialTheme.typography.titleSmall
                )
                Text(
                    text = "Required by Android for Bluetooth scanning. We do NOT track your location.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "🔒 All messages are end-to-end encrypted and never stored.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        },
        confirmButton = {
            Button(onClick = onGrantPermissions) {
                Text("Grant Permissions")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

// ============================================================================
// END OF COMPLETE MAINACTIVITY
// ============================================================================