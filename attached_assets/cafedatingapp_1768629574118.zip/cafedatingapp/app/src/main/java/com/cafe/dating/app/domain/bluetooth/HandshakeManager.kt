package com.cafe.dating.app.domain.bluetooth


import com.cafe.dating.app.data.encryption.EncryptionUtils
import java.io.InputStream
import java.io.OutputStream
import javax.crypto.SecretKey

/**
 * Secure handshake protocol for establishing encrypted connections
 *
 * Protocol:
 * 1. Client → Server: HELLO|clientUUID|clientName
 * 2. Server → Client: ACCEPT|sessionKey OR REJECT|reason
 * 3. Both: Begin encrypted communication
 */
class HandshakeManager {

    companion object {
        private const val HELLO = "HELLO"
        private const val ACCEPT = "ACCEPT"
        private const val REJECT = "REJECT"
        private const val DELIMITER = "|"
        private const val TIMEOUT_MS = 10000L
    }

    /**
     * Client-side handshake
     * Returns session key if successful, null otherwise
     */
    fun performClientHandshake(
        input: InputStream,
        output: OutputStream,
        clientUUID: String,
        clientName: String
    ): SecretKey? {
        return try {
            // Send HELLO message
            val helloMsg = "$HELLO$DELIMITER$clientUUID$DELIMITER$clientName\n"
            output.write(helloMsg.toByteArray())
            output.flush()

            // Wait for ACCEPT or REJECT
            val response = readLineWithTimeout(input, TIMEOUT_MS)
            val parts = response.split(DELIMITER)

            when (parts[0]) {
                ACCEPT -> {
                    if (parts.size >= 2) {
                        EncryptionUtils.stringToKey(parts[1])
                    } else null
                }
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Server-side handshake
     * Returns client info and session key if accepted, null if rejected
     */
    fun performServerHandshake(
        input: InputStream,
        output: OutputStream,
        onConnectionRequest: (String, String) -> Boolean // (uuid, name) -> accepted
    ): Pair<String, SecretKey>? {
        return try {
            // Read HELLO message
            val helloMsg = readLineWithTimeout(input, TIMEOUT_MS)
            val parts = helloMsg.split(DELIMITER)

            if (parts[0] != HELLO || parts.size < 3) {
                sendReject(output, "Invalid handshake")
                return null
            }

            val clientUUID = parts[1]
            val clientName = parts[2]

            // Ask user for permission
            val accepted = onConnectionRequest(clientUUID, clientName)

            if (accepted) {
                // Generate session key
                val sessionKey = EncryptionUtils.generateSessionKey()
                val keyString = EncryptionUtils.keyToString(sessionKey)

                // Send ACCEPT with session key
                val acceptMsg = "$ACCEPT$DELIMITER$keyString\n"
                output.write(acceptMsg.toByteArray())
                output.flush()

                Pair(clientUUID, sessionKey)
            } else {
                sendReject(output, "User declined")
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun sendReject(output: OutputStream, reason: String) {
        try {
            val rejectMsg = "$REJECT$DELIMITER$reason\n"
            output.write(rejectMsg.toByteArray())
            output.flush()
        } catch (e: Exception) {
            // Ignore
        }
    }

    private fun readLineWithTimeout(input: InputStream, timeoutMs: Long): String {
        val buffer = StringBuilder()
        val startTime = System.currentTimeMillis()

        while (System.currentTimeMillis() - startTime < timeoutMs) {
            if (input.available() > 0) {
                val char = input.read().toChar()
                if (char == '\n') break
                buffer.append(char)
            } else {
                Thread.sleep(10)
            }
        }

        return buffer.toString()
    }
}