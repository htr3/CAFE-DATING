package com.cafe.dating.app.data.local

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.util.UUID

/**
 * Secure storage for app-specific device UUID and settings
 */
class SecurePreferences(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "secure_cafe_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    /**
     * Get or generate unique device UUID for this app installation
     */
    fun getDeviceUUID(): String {
        var uuid = prefs.getString(KEY_DEVICE_UUID, null)
        if (uuid == null) {
            uuid = UUID.randomUUID().toString()
            prefs.edit().putString(KEY_DEVICE_UUID, uuid).apply()
        }
        return uuid
    }

    /**
     * Get user display name (optional)
     */
    fun getDisplayName(): String {
        return prefs.getString(KEY_DISPLAY_NAME, android.os.Build.MODEL) ?: android.os.Build.MODEL
    }

    /**
     * Set user display name
     */
    fun setDisplayName(name: String) {
        prefs.edit().putString(KEY_DISPLAY_NAME, name).apply()
    }

    companion object {
        private const val KEY_DEVICE_UUID = "device_uuid"
        private const val KEY_DISPLAY_NAME = "display_name"
    }
}