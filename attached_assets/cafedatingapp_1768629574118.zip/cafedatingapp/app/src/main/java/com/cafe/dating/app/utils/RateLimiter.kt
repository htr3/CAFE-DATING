package com.cafe.dating.app.utils


/**
 * Rate limiter to prevent message spam
 * Max 5 messages per second per connection
 */
class RateLimiter(
    private val maxMessages: Int = 5,
    private val timeWindowMs: Long = 1000
) {
    private val timestamps = mutableListOf<Long>()

    /**
     * Check if action is allowed
     */
    @Synchronized
    fun isAllowed(): Boolean {
        val now = System.currentTimeMillis()

        // Remove old timestamps outside the window
        timestamps.removeAll { it < now - timeWindowMs }

        if (timestamps.size >= maxMessages) {
            return false
        }

        timestamps.add(now)
        return true
    }

    /**
     * Reset the rate limiter
     */
    @Synchronized
    fun reset() {
        timestamps.clear()
    }
}
