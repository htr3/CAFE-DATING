package com.cafe.dating.app.domain.bluetooth


import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import com.cafe.dating.app.data.local.SecurePreferences
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import java.util.UUID

/**
 * Bluetooth RFCOMM Client
 * Connects to remote devices and performs secure handshake
 */
class BluetoothClient(
    private val bluetoothAdapter: BluetoothAdapter?,
    private val securePrefs: SecurePreferences
) {

    companion object {
        private val APP_UUID = UUID.fromString("8ce255c0-200a-11e0-ac64-0800200c9a66")
    }

    private val _connectionFlow = MutableSharedFlow<ClientEvent>()
    val connectionFlow: SharedFlow<ClientEvent> = _connectionFlow

    sealed class ClientEvent {
        object Connecting : ClientEvent()
        data class Connected(val socket: SecureSocketManager, val deviceUUID: String) : ClientEvent()
        data class Failed(val reason: String) : ClientEvent()
    }

    /**
     * Connect to a remote device
     */
    suspend fun connect(
        context: android.content.Context,
        deviceAddress: String
    ): SecureSocketManager? {
        if (bluetoothAdapter == null) {
            _connectionFlow.emit(ClientEvent.Failed("Bluetooth not available"))
            return null
        }

        // Check permissions
        if (ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.BLUETOOTH_CONNECT
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            _connectionFlow.emit(ClientEvent.Failed("Permission denied"))
            return null
        }

        _connectionFlow.emit(ClientEvent.Connecting)

        return try {
            // Cancel discovery to improve connection speed
            bluetoothAdapter.cancelDiscovery()

            // Get remote device
            val device: BluetoothDevice = bluetoothAdapter.getRemoteDevice(deviceAddress)

            // Create RFCOMM socket
            val socket: BluetoothSocket = device.createRfcommSocketToServiceRecord(APP_UUID)

            // Connect (BLOCKS)
            socket.connect()

            // Perform handshake
            val handshakeManager = HandshakeManager()
            val myUUID = securePrefs.getDeviceUUID()
            val myName = securePrefs.getDisplayName()

            val sessionKey = handshakeManager.performClientHandshake(
                socket.inputStream,
                socket.outputStream,
                myUUID,
                myName
            )

            if (sessionKey != null) {
                val secureSocket = SecureSocketManager(socket, sessionKey, myUUID)
                _connectionFlow.emit(ClientEvent.Connected(secureSocket, myUUID))
                secureSocket
            } else {
                socket.close()
                _connectionFlow.emit(ClientEvent.Failed("Handshake failed"))
                null
            }
        } catch (e: Exception) {
            _connectionFlow.emit(ClientEvent.Failed(e.message ?: "Connection failed"))
            null
        }
    }
}
