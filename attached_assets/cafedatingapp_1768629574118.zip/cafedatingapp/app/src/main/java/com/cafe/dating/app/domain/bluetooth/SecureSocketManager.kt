package com.cafe.dating.app.domain.bluetooth


import android.bluetooth.BluetoothSocket
import com.cafe.dating.app.data.encryption.EncryptionUtils
import com.cafe.dating.app.data.model.ChatMessage
import com.cafe.dating.app.utils.RateLimiter
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import java.io.IOException
import java.util.UUID
import javax.crypto.SecretKey

class SecureSocketManager(
    private val socket: BluetoothSocket,
    private val sessionKey: SecretKey,
    private val remoteDeviceUUID: String
) {
    private val input = socket.inputStream
    private val output = socket.outputStream
    private val rateLimiter = RateLimiter(maxMessages = 5, timeWindowMs = 1000)

    private val _messageFlow = MutableSharedFlow<ChatMessage>()
    val messageFlow: SharedFlow<ChatMessage> = _messageFlow

    private val _connectionState = MutableSharedFlow<ConnectionState>()
    val connectionState: SharedFlow<ConnectionState> = _connectionState

    @Volatile
    private var isRunning = false
    private var listenerThread: Thread? = null

    sealed class ConnectionState {
        object Connected : ConnectionState()
        object Disconnected : ConnectionState()
        data class Error(val message: String) : ConnectionState()
    }

    fun startListening() {
        if (isRunning) return

        isRunning = true
        listenerThread = Thread {
            try {
                _connectionState.tryEmit(ConnectionState.Connected)

                while (isRunning && socket.isConnected) {
                    val encryptedMessage = readMessage()
                    if (encryptedMessage != null) {
                        handleIncomingMessage(encryptedMessage)
                    }
                }
            } catch (e: IOException) {
                _connectionState.tryEmit(ConnectionState.Disconnected)
            } catch (e: Exception) {
                _connectionState.tryEmit(ConnectionState.Error(e.message ?: "Unknown error"))
            } finally {
                isRunning = false
            }
        }.apply { start() }
    }

    fun sendMessage(message: String): Boolean {
        if (!rateLimiter.isAllowed()) {
            return false
        }

        return try {
            val encrypted = EncryptionUtils.encrypt(message, sessionKey)
            val data = "$encrypted\n".toByteArray()

            synchronized(output) {
                output.write(data)
                output.flush()
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun close() {
        isRunning = false
        try {
            listenerThread?.interrupt()
            input.close()
            output.close()
            socket.close()
        } catch (e: Exception) {
            // Ignore
        }
    }

    private fun readMessage(): String? {
        val buffer = StringBuilder()

        try {
            while (isRunning) {
                if (input.available() > 0) {
                    val char = input.read().toChar()
                    if (char == '\n') break
                    buffer.append(char)
                } else {
                    Thread.sleep(10)
                }
            }

            return if (buffer.isNotEmpty()) buffer.toString() else null
        } catch (e: Exception) {
            return null
        }
    }

    private fun handleIncomingMessage(encryptedMessage: String) {
        try {
            val decrypted = EncryptionUtils.decrypt(encryptedMessage, sessionKey)
            val chatMessage = ChatMessage(
                id = UUID.randomUUID().toString(),
                content = decrypted,
                timestamp = System.currentTimeMillis(),
                isSent = false,
                isEncrypted = true
            )
            _messageFlow.tryEmit(chatMessage)
        } catch (e: Exception) {
            // Decryption failed - ignore message
        }
    }
}
