package com.cafe.dating.app.data.model

data class ConnectionRequest(
    val fromDevice: BluetoothDeviceModel,
    val timestamp: Long
)