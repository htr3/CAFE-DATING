package com.cafe.dating.app.presentation.viewmodels


import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cafe.dating.app.data.model.ChatMessage
import com.cafe.dating.app.domain.bluetooth.SecureSocketManager
import com.cafe.dating.app.domain.usecases.SendMessageUseCase
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

/**
 * ViewModel for managing chat state and messages
 */
class ChatViewModel : ViewModel() {

    private val sendMessageUseCase = SendMessageUseCase()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _sendState = MutableStateFlow<SendState>(SendState.Idle)
    val sendState: StateFlow<SendState> = _sendState.asStateFlow()

    private var currentSocket: SecureSocketManager? = null
    private var connectedDeviceName: String = ""

    sealed class ConnectionState {
        object Disconnected : ConnectionState()
        data class Connected(val deviceName: String) : ConnectionState()
    }

    sealed class SendState {
        object Idle : SendState()
        object Sending : SendState()
        object RateLimited : SendState()
        data class Error(val message: String) : SendState()
    }

    /**
     * Initialize chat with a socket connection
     */
    fun initializeChat(socket: SecureSocketManager, deviceName: String) {
        currentSocket = socket
        connectedDeviceName = deviceName
        _connectionState.value = ConnectionState.Connected(deviceName)
        _messages.value = emptyList()

        // Start listening for messages
        socket.startListening()

        // Collect incoming messages
        viewModelScope.launch {
            socket.messageFlow.collect { message ->
                addMessage(message)
            }
        }

        // Collect connection state changes
        viewModelScope.launch {
            socket.connectionState.collect { state ->
                when (state) {
                    is SecureSocketManager.ConnectionState.Disconnected -> {
                        _connectionState.value = ConnectionState.Disconnected
                    }
                    is SecureSocketManager.ConnectionState.Error -> {
                        _connectionState.value = ConnectionState.Disconnected
                    }
                    else -> {}
                }
            }
        }
    }

    /**
     * Send a message
     */
    fun sendMessage(content: String) {
        if (_sendState.value is SendState.Sending) return

        _sendState.value = SendState.Sending

        viewModelScope.launch {
            when (val result = sendMessageUseCase(content, currentSocket)) {
                is SendMessageUseCase.Result.Success -> {
                    addMessage(result.message)
                    _sendState.value = SendState.Idle
                }
                is SendMessageUseCase.Result.RateLimited -> {
                    _sendState.value = SendState.RateLimited
                    // Reset after 1 second
                    kotlinx.coroutines.delay(1000)
                    _sendState.value = SendState.Idle
                }
                is SendMessageUseCase.Result.Failure -> {
                    _sendState.value = SendState.Error(result.error)
                    kotlinx.coroutines.delay(2000)
                    _sendState.value = SendState.Idle
                }
            }
        }
    }

    /**
     * Disconnect from chat
     */
    fun disconnect() {
        currentSocket?.close()
        currentSocket = null
        _connectionState.value = ConnectionState.Disconnected
        _messages.value = emptyList()
    }

    /**
     * Block the current user
     */
    fun blockUser(onBlock: (String) -> Unit) {
        // Get device UUID from socket
        currentSocket?.let { socket ->
            // Block device (delegate to parent ViewModel)
            disconnect()
        }
    }

    private fun addMessage(message: ChatMessage) {
        val currentMessages = _messages.value.toMutableList()
        currentMessages.add(message)
        _messages.value = currentMessages
    }

    override fun onCleared() {
        super.onCleared()
        disconnect()
    }
}