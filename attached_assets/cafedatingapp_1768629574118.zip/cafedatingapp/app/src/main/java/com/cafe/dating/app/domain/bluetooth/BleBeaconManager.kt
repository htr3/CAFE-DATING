package com.cafe.dating.app.domain.bluetooth

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.content.Context
import android.content.pm.PackageManager

import android.os.Build
import androidx.core.app.ActivityCompat
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.text.Charsets

@Singleton
class BleBeaconManager @Inject constructor(
    private val context: Context,
    private val bluetoothAdapter: BluetoothAdapter?
) {
    private val advertiser = bluetoothAdapter?.bluetoothLeAdvertiser

    private val advertiseSettings = AdvertiseSettings.Builder()
        .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
        .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
        .setConnectable(false)
        .build()

    private val advertiseCallback = object : AdvertiseCallback() {
        override fun onStartSuccess(settingsInEffect: AdvertiseSettings) {
            super.onStartSuccess(settingsInEffect)
        }
    }

    fun startAdvertising(userId: String) {
        if (advertiser == null || !checkPermissions()) return

        // 1. Main Packet: Contains your unique UserID
        val data = AdvertiseData.Builder()
            .addManufacturerData(0x07FF, userId.toByteArray(Charsets.UTF_8))
            .setIncludeTxPowerLevel(false)
            .build()

        // 2. Scan Response: Holds the name so the first packet stays small
        val scanResponse = AdvertiseData.Builder()
            .setIncludeDeviceName(true)
            .build()

        try {
            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_ADVERTISE) == PackageManager.PERMISSION_GRANTED || Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
                advertiser.startAdvertising(advertiseSettings, data, scanResponse, advertiseCallback)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun stopAdvertising() {
        try {
            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_ADVERTISE) == PackageManager.PERMISSION_GRANTED || Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
                advertiser?.stopAdvertising(advertiseCallback)
            }
        } catch (e: Exception) { /* Ignore */ }
    }

    private fun checkPermissions(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ActivityCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_ADVERTISE) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }
}