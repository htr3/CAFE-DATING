package com.cafe.dating.app.domain.usecases


import com.cafe.dating.app.data.model.ChatMessage
import com.cafe.dating.app.domain.bluetooth.SecureSocketManager
import java.util.UUID

/**
 * Use case for sending encrypted messages
 * Handles message validation and rate limiting
 */
class SendMessageUseCase {

    sealed class Result {
        data class Success(val message: ChatMessage) : Result()
        object RateLimited : Result()
        data class Failure(val error: String) : Result()
    }

    /**
     * Send a message through secure socket
     */
    operator fun invoke(
        content: String,
        socket: SecureSocketManager?
    ): Result {
        // Validate message
        if (content.isBlank()) {
            return Result.Failure("Message cannot be empty")
        }

        if (content.length > 1000) {
            return Result.Failure("Message too long (max 1000 characters)")
        }

        if (socket == null) {
            return Result.Failure("Not connected")
        }

        // Send message
        val sent = socket.sendMessage(content)

        return if (sent) {
            // Create message for local display
            val message = ChatMessage(
                id = UUID.randomUUID().toString(),
                content = content,
                timestamp = System.currentTimeMillis(),
                isSent = true,
                isEncrypted = true
            )
            Result.Success(message)
        } else {
            Result.RateLimited
        }
    }
}
